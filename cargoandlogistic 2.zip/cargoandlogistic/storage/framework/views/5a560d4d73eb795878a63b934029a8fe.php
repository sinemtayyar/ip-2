<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comment System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }
        .comment-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .comment-container h1 {
            background: #4CAF50;
            color: white;
            margin: 0;
            padding: 15px;
            text-align: center;
        }
        .comment-form {
            padding: 20px;
            border-bottom: 1px solid #ddd;
        }
        .comment-form input, .comment-form textarea {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .comment-form button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .comment-form button:hover {
            background: #45a049;
        }
        .comments {
            padding: 20px;
        }
        .comment {
            margin-bottom: 15px;
            padding: 10px;
            border-left: 4px solid #4CAF50;
            background: #f9f9f9;
            border-radius: 4px;
        }
        .comment .name {
            font-weight: bold;
            color: #333;
        }
        .comment .content {
            margin-top: 5px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>
<div class="comment-container">
    <h1>Comments</h1>
    <form action="<?php echo e(route('comments.store')); ?>" method="POST" class="comment-form">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Your Name" required>
        <textarea name="content" rows="4" placeholder="Your Comment" required></textarea>
        <button type="submit">Add Comment</button>
    </form>
    <div class="comments">
        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="comment">
                <div class="name"><?php echo e($comment['name']); ?></div>
                <div class="content"><?php echo e($comment['body']); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No comments yet. Be the first to comment!</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php /**PATH /Users/sinemtayyar/cargoandlogistic/resources/views/index.blade.php ENDPATH**/ ?>