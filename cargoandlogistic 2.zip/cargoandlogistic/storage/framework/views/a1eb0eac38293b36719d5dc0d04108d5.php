<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShipEasy</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #007bff !important;
        }

        .nav-link {
            color: #555 !important;
        }

        .nav-link:hover {
            color: #007bff !important;
        }

        .btn-login, .btn-register {
            margin-left: 10px;
        }
        .tracking-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 50px auto;
            max-width: 600px;
            text-align: center;
        }
        .tracking-section h2 {
            font-weight: bold;
            margin-bottom: 20px;
            color: #4a4a4a;
        }
        .tracking-section input {
            border: 2px solid #2196f3;
            border-radius: 30px;
            padding: 10px 15px;
            width: 70%;
            outline: none;
        }
        .tracking-section button {
            border-radius: 30px;
            background: linear-gradient(135deg, #42a5f5, #e91e63);
            color: white;
            padding: 10px 25px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="#">ShipEasy</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Services</a>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('comments.index')); ?>">Comments</a>
                </li>
                </li>
            </ul>
            <!-- Login/Register Buttons -->
            <div class="d-flex">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary me-2">Login/Register</a>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit">Logout</button>
            </form>

        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container text-center mt-5">
    <h1>Welcome to ShipEasy!</h1>
    <p class="lead">Your reliable solution for all shipping needs.</p>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card">
            <img src="https://i.pinimg.com/736x/67/d8/f2/67d8f2e9307a14cadf2d44129216e718.jpg" class="card-img-top" alt="Placeholder Image">
            <div class="card-body">
                <p class="card-text"> </p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <img src="https://i.pinimg.com/736x/f8/e3/65/f8e365a8ee70bdb0fb28ce9811200cc4.jpg" class="card-img-top" alt="Placeholder Image">
            <div class="card-body">
                <h5 class="card-title"></h5>
                <p class="card-text">We deliver your cargo to you as quickly as possible</p>
            </div>
        </div>
    </div>
</div>
</div>


<div class="tracking-section">
    <h2>Track Your Delivery</h2>
    <p>Enter your tracking number to get the latest status of your parcel.</p>

    <form action="<?php echo e(route('shipment.track')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <input type="text" id="trackingInput" placeholder="Enter Tracking Number" required>
            <button id="trackBtn">Shipment Status</button>
        </div>
    </form>

    <?php if(isset($status)): ?>
        <div>
            <h3>Shipment Status:</h3>
            <p><?php echo e($status); ?></p>
        </div>
    <?php endif; ?>

</div>

<script>
    document.getElementById('trackBtn').addEventListener('click', function() {
        const input = document.getElementById('trackingInput').value;
        const result = document.getElementById('result');

        if (input) {
            result.style.display = 'block';
        } else {
            alert('Please enter a tracking number!');
        }
    });
</script>
<footer class="footer">
    <div class="container text-center">
        <p>&copy; 2024 ShipEasy. All Rights Reserved.</p>
        <p>Follow us on:
            <a href="#">Facebook</a> |
            <a href="#">Twitter</a> |
            <a href="#">Instagram</a>
        </p>
    </div>
</footer>

<!-- Bootstrap JS -->
</body>
</html>
<?php /**PATH /Users/sinemtayyar/cargoandlogistic/resources/views/welcome.blade.php ENDPATH**/ ?>