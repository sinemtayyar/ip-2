<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;


class UserSeeder extends Seeder
{

    public function run()
    {
        User::create([
            'name' => 'John Doe',
            'email' => 'john.doe@example.com',
            'password' => Hash::make('password'), // Şifreyi hashliyoruz
            'phone' => '1234567890',
        ]);
        User::create([
            'name' => ' Jane Sol',
            'email' => 'soljane@gmail.com',
            'password' => Hash::make('password'), // Şifreyi hashliyoruz
            'phone' => '05064531221',
        ]);
        User::create([
            'name' => 'İrem Soyu',
            'email' => 'soylu@gmail.com@gmail.com',
            'password' => Hash::make('password'), // Şifreyi hashliyoruz
            'phone' => '05072346754',
        ]);
        User::create([
            'name' => ' Fikri Doğmaz',
            'email' => 'fikrid@gmail.com',
            'password' => Hash::make('password'), // Şifreyi hashliyoruz
            'phone' => '005064586721',
        ]);
        User::create([
            'name' => 'Ferdi Lal',
            'email' => 'ferdilal23@gmail.com@example.com',
            'password' => Hash::make('password'), // Şifreyi hashliyoruz
            'phone' => '05081234323',
        ]);

    }
}

