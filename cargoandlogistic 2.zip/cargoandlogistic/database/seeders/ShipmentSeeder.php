<?php

namespace Database\Seeders;

use App\Models\Shipment;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ShipmentSeeder extends Seeder
{
    public function run()
    {

        Shipment::create([
            'user_id' => 1,
            'order_id' => 1,
            'shipment_date' => Carbon::now()->addDays(3),  // 3 gün sonrası
            'payment_id' => 1001,
            'delivery_address' => '123 Example St, Example City',  // Teslimat adresi
            'datetime' => Carbon::now(),  // Şu anki tarih ve saat
        ]);


    }
}
