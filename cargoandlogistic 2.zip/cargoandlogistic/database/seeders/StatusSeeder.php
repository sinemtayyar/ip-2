<?php

namespace Database\Seeders;

use App\Models\Status;
use Illuminate\Database\Seeder;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $status = ['Pending', 'Delivered', 'Shipped'];
        foreach ($status as $status)

            Status::create([
                'shipment_id'=> '1',
            'tracking_number' => '12345678901',
            'status' => 'Shipped',
                'changed_at'=>now(),
        ]);

        Status::create([
            'shipment_id'=> '2',
            'changed_at'=>now(),
            'tracking_number' => '23456789012',
            'status' => 'Pending',

        ]);

        Status::create([
            'shipment_id'=> '3',
            'changed_at'=>now(),
            'tracking_number' => '34567890123',
            'status' => 'Delivered',
        ]);

    }

}
