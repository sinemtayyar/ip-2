# ip-2
 
 kargo ve lojistik yönetimi ödevim kayıt olunan email ve şifreyle login olmasını ve yorumlarla databese bağlantısını kurdum.
