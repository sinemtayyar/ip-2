<?php
namespace App\Http\Controllers;

use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{


public function index()
{
$comments = session()->get('comments', []);

return view('comments.index', compact('comments'));
}

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:255',
            'comment' => 'required',
        ]);


        Comment::create([
            'name' => $request->name,
            'comment' => $request->comment,
            'user_id' => auth()->id(),
        ]);

        return redirect()->route('comments.index')->with('success', 'Your comment has been successfully sent.');
    }

}
