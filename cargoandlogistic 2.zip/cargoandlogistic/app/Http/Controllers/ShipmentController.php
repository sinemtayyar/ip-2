<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ShipmentController extends Controller
{
    public function track(Request $request)
    {
        $request->validate([
            'tracking_number' => 'required|string',
        ]);

        $shipment = Shipment::where('tracking_number', $request->tracking_number)->first();

        if ($shipment) {
            $status = $shipment->status;
        } else {
            $status = 'Takip numarası bulunamadı.';
        }

        return view('welcome', ['status' => $status]);
    }

}
