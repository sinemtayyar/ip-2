<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Comment extends Model
{
    use HasFactory;
    public $timestamps = false;

    protected $fillable = ['name', 'comment'];

    public function user()
    {
        return $this->belongsTo(User::class); // Yorumun bir kullanıcıya ait olduğunu belirtir
    }
}
